class RIPRouter:
    def __init__(self, name):
        self.name = name
        self.routing_table = {}
    
    def update_table(self, neighbor, neighbor_table):
        for dest, hop_count in neighbor_table.items():
            new_hop_count = hop_count + 1  # Add a hop to the neighbor
            if dest not in self.routing_table or self.routing_table[dest] > new_hop_count:
                self.routing_table[dest] = new_hop_count

    def send_update(self, neighbors):
        for neighbor in neighbors:
            neighbor.update_table(self.name, self.routing_table)

    def print_routing_table(self):
        print(f"Routing Table for {self.name}:")
        for dest, hop_count in self.routing_table.items():
            print(f"  Destination: {dest}, Hop Count: {hop_count}")


# Create a small network
routerA = RIPRouter('A')
routerB = RIPRouter('B')
routerC = RIPRouter('C')
routerD = RIPRouter('D')

# Initialize the routing tables with direct neighbors
routerA.routing_table = {'A': 0, 'B': 1, 'C': 3}
routerB.routing_table = {'B': 0, 'A': 1, 'D': 1}
routerC.routing_table = {'C': 0, 'A': 3}
routerD.routing_table = {'D': 0, 'B': 1}

# Perform a few rounds of RIP updates
for i in range(3):
    print(f"Round {i+1}")
    routerA.send_update([routerB, routerC])
    routerB.send_update([routerA, routerD])
    routerC.send_update([routerA])
    routerD.send_update([routerB])

    routerA.print_routing_table()
    routerB.print_routing_table()
    routerC.print_routing_table()
    routerD.print_routing_table()
    print("----------------------------")

 
