import heapq

class OSPFRouter:
    def __init__(self, name, links):
        self.name = name
        self.links = links  # Links is a dictionary of neighbors with cost

    def dijkstra(self, network):
        distances = {router: float('inf') for router in network}
        distances[self.name] = 0
        priority_queue = [(0, self.name)]
        while priority_queue:
            current_distance, current_router = heapq.heappop(priority_queue)

            # If we find a larger distance in the queue, we skip processing
            if current_distance > distances[current_router]:
                continue

            for neighbor, weight in network[current_router].links.items():
                distance = current_distance + weight

                if distance < distances[neighbor]:
                    distances[neighbor] = distance
                    heapq.heappush(priority_queue, (distance, neighbor))

        return distances

    def print_shortest_paths(self, distances):
        print(f"Shortest paths from {self.name}:")
        for dest, distance in distances.items():
            print(f"  To {dest}: {distance}")


# Create the network as a graph
network = {
    'A': OSPFRouter('A', {'B': 1, 'C': 3}),
    'B': OSPFRouter('B', {'A': 1, 'D': 1}),
    'C': OSPFRouter('C', {'A': 3}),
    'D': OSPFRouter('D', {'B': 1}),
}

# Each router runs Dijkstra's algorithm
for router_name, router in network.items():
    distances = router.dijkstra(network)
    router.print_shortest_paths(distances)
    print("----------------------------")
