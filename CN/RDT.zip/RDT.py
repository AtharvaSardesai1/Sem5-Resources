import time
import random

# Simulating an unreliable channel
def unreliable_channel(packet):
    """ Simulate an unreliable network where packets might get lost. """
    if random.choice([True, False]):  # Randomly drop a packet
        print(f"Packet {packet['seq']} was lost.")
        return False  # Packet was lost
    return True  # Packet was successfully sent

# Sender side implementation
def rdt_sender(data):
    """ Implements the reliable data transfer sender using stop-and-wait protocol. """
    seq_num = 0
    for message in data:
        packet = {'seq': seq_num, 'data': message}  # Create a packet with sequence number
        ack_received = False

        while not ack_received:
            print(f"Sender: Sending Packet {packet['seq']} with data: {packet['data']}")
            if unreliable_channel(packet):
                ack_received = simulate_ack_receiver(packet['seq'])  # Simulate receiver acknowledgment
            else:
                print(f"Sender: Timeout for Packet {packet['seq']}. Retransmitting...")
                time.sleep(1)  # Simulate retransmission delay

        seq_num = (seq_num + 1) % 2  # Alternate sequence number (0 or 1)

# Receiver side implementation
def simulate_ack_receiver(expected_seq):
    """ Simulates the receiver side for acknowledging packets. """
    ack_lost = random.choice([True, False])  # Simulate ack loss
    if ack_lost:
        print(f"Receiver: ACK for Packet {expected_seq} was lost.")
        return False
    else:
        print(f"Receiver: ACK received for Packet {expected_seq}.")
        return True

# Example usage:
data = ["Frame1", "Frame2", "Frame3", "Frame4", "Frame5"]
rdt_sender(data)
